using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace YUJIII
{
    public partial class CreateAbonente : Form
    {
        private ErrorProvider errorProvider;
        private string filePath;
        private ContextMenuStrip contextMenu;

        public CreateAbonente()
        {
            InitializeComponent();

            errorProvider = new ErrorProvider();
            errorProvider.BlinkStyle = ErrorBlinkStyle.NeverBlink;

            filePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                "contacts.txt");

            textBoxName.TextChanged += ValidateField;
            textBoxLastName.TextChanged += ValidateField;
            textBoxDadsName.TextChanged += ValidateField;
            textBoxPhone.TextChanged += ValidateField;
            textBoxAge.TextChanged += ValidateField;

            buttonAccept.Click += ButtonAccept_Click;
            buttonStop.Click += ButtonStop_Click;

            contextMenu = new ContextMenuStrip();
            var deleteItem = new ToolStripMenuItem("��������");
            deleteItem.Click += DeleteItem_Click;
            contextMenu.Items.Add(deleteItem);

            listBoxAbonents.ContextMenuStrip = contextMenu;

            LoadAbonentsFromFile();
        }

        private void LoadAbonentsFromFile()
        {
            if (!File.Exists(filePath))
                return;

            listBoxAbonents.Items.Clear();

            string[] lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
            {
                string[] parts = line.Split(';');

                if (parts.Length >= 4)
                {
                    string shortInfo = $"{parts[0]} {parts[1]} - {parts[3]}";
                    listBoxAbonents.Items.Add(shortInfo);
                }
            }
        }

        private void ButtonAccept_Click(object? sender, EventArgs e)
        {
            if (!ValidateForm())
                return;

            string abonentInfo =
                $"{textBoxName.Text};" +
                $"{textBoxLastName.Text};" +
                $"{textBoxDadsName.Text};" +
                $"{textBoxPhone.Text};" +
                $"{textBoxAge.Text}";

            File.AppendAllText(filePath, abonentInfo + Environment.NewLine);

            LoadAbonentsFromFile();
            ClearFields();
        }

        private bool ValidateForm()
        {
            bool valid = true;

            if (!ValidateSingleField(textBoxName, "������ ��'�!"))
                valid = false;

            if (!ValidateSingleField(textBoxLastName, "������ �������!"))
                valid = false;

            if (!ValidateSingleField(textBoxDadsName, "������ �� �������!"))
                valid = false;

            if (!ValidateSingleField(textBoxPhone, "������ �������!"))
                valid = false;

            if (!int.TryParse(textBoxAge.Text, out int age) || age <= 0)
            {
                errorProvider.SetError(textBoxAge, "������ ��������� ��!");
                textBoxAge.BackColor = Color.MistyRose;
                valid = false;
            }
            else
            {
                errorProvider.SetError(textBoxAge, "");
                textBoxAge.BackColor = Color.White;
            }

            return valid;
        }

        private bool ValidateSingleField(TextBox box, string message)
        {
            if (string.IsNullOrWhiteSpace(box.Text))
            {
                errorProvider.SetError(box, message);
                box.BackColor = Color.MistyRose;
                return false;
            }
            else
            {
                errorProvider.SetError(box, "");
                box.BackColor = Color.White;
                return true;
            }
        }

        private void ValidateField(object? sender, EventArgs e)
        {
            if (sender is TextBox box)
            {
                if (string.IsNullOrWhiteSpace(box.Text))
                {
                    errorProvider.SetError(box, "���� �� ���� ���� ��������!");
                    box.BackColor = Color.MistyRose;
                }
                else
                {
                    errorProvider.SetError(box, "");
                    box.BackColor = Color.White;
                }
            }
        }

        private void DeleteItem_Click(object? sender, EventArgs e)
        {
            if (listBoxAbonents.SelectedItem == null)
                return;

            string selected = listBoxAbonents.SelectedItem.ToString()!;
            string[] displayParts = selected.Split('-');

            if (displayParts.Length != 2)
                return;

            string namePart = displayParts[0].Trim();
            string phonePart = displayParts[1].Trim();

            if (!File.Exists(filePath))
                return;

            var lines = new System.Collections.Generic.List<string>(File.ReadAllLines(filePath));

            lines.RemoveAll(line =>
            {
                string[] parts = line.Split(';');
                if (parts.Length < 4) return false;
                return $"{parts[0]} {parts[1]}" == namePart && parts[3] == phonePart;
            });

            File.WriteAllLines(filePath, lines);
            LoadAbonentsFromFile();
        }

        private void ButtonStop_Click(object? sender, EventArgs e)
        {
            Close();
        }

        private void ClearFields()
        {
            textBoxName.Clear();
            textBoxLastName.Clear();
            textBoxDadsName.Clear();
            textBoxPhone.Clear();
            textBoxAge.Clear();
        }
        private void listBoxAbonents_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (listBoxAbonents.SelectedItem == null)
                return;

            MessageBox.Show(listBoxAbonents.SelectedItem.ToString());
        }
    }
}