﻿namespace YUJIII
{
    partial class CreateAbonente
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxLastName;
        private System.Windows.Forms.TextBox textBoxDadsName;
        private System.Windows.Forms.TextBox textBoxPhone;
        private System.Windows.Forms.TextBox textBoxAge;
        private System.Windows.Forms.Button buttonAccept;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Button buttonCreateAbonent;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            textBoxName = new TextBox();
            textBoxLastName = new TextBox();
            textBoxDadsName = new TextBox();
            textBoxPhone = new TextBox();
            textBoxAge = new TextBox();
            buttonAccept = new Button();
            buttonStop = new Button();
            buttonCreateAbonent = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            listBoxAbonents = new ListBox();
            label7 = new Label();
            SuspendLayout();
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(128, 49);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(200, 23);
            textBoxName.TabIndex = 0;
            // 
            // textBoxLastName
            // 
            textBoxLastName.Location = new Point(128, 100);
            textBoxLastName.Name = "textBoxLastName";
            textBoxLastName.Size = new Size(200, 23);
            textBoxLastName.TabIndex = 1;
            // 
            // textBoxDadsName
            // 
            textBoxDadsName.Location = new Point(128, 149);
            textBoxDadsName.Name = "textBoxDadsName";
            textBoxDadsName.Size = new Size(200, 23);
            textBoxDadsName.TabIndex = 2;
            // 
            // textBoxPhone
            // 
            textBoxPhone.Location = new Point(128, 198);
            textBoxPhone.Name = "textBoxPhone";
            textBoxPhone.Size = new Size(200, 23);
            textBoxPhone.TabIndex = 3;
            // 
            // textBoxAge
            // 
            textBoxAge.Location = new Point(128, 244);
            textBoxAge.Name = "textBoxAge";
            textBoxAge.Size = new Size(200, 23);
            textBoxAge.TabIndex = 4;
            // 
            // buttonAccept
            // 
            buttonAccept.Location = new Point(128, 296);
            buttonAccept.Name = "buttonAccept";
            buttonAccept.Size = new Size(90, 30);
            buttonAccept.TabIndex = 5;
            buttonAccept.Text = "Прийняти";
            // 
            // buttonStop
            // 
            buttonStop.Location = new Point(238, 296);
            buttonStop.Name = "buttonStop";
            buttonStop.Size = new Size(90, 30);
            buttonStop.TabIndex = 6;
            buttonStop.Text = "Закрити";
            // 
            // buttonCreateAbonent
            // 
            buttonCreateAbonent.Location = new Point(128, 352);
            buttonCreateAbonent.Name = "buttonCreateAbonent";
            buttonCreateAbonent.Size = new Size(200, 30);
            buttonCreateAbonent.TabIndex = 7;
            buttonCreateAbonent.Text = "Створити абонента";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F);
            label1.ForeColor = Color.Blue;
            label1.Location = new Point(48, -1);
            label1.Name = "label1";
            label1.Size = new Size(222, 37);
            label1.TabIndex = 8;
            label1.Text = "Введіть свої дані";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F);
            label2.ForeColor = Color.Purple;
            label2.Location = new Point(78, 49);
            label2.Name = "label2";
            label2.Size = new Size(44, 25);
            label2.TabIndex = 9;
            label2.Text = "Ім'я";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14F);
            label3.ForeColor = Color.Purple;
            label3.Location = new Point(25, 100);
            label3.Name = "label3";
            label3.Size = new Size(97, 25);
            label3.TabIndex = 10;
            label3.Text = "Прізвище";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14F);
            label4.ForeColor = Color.Purple;
            label4.Location = new Point(35, 198);
            label4.Name = "label4";
            label4.Size = new Size(87, 25);
            label4.TabIndex = 11;
            label4.Text = "Телефон";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 14F);
            label5.ForeColor = Color.Purple;
            label5.Location = new Point(6, 149);
            label5.Name = "label5";
            label5.Size = new Size(116, 25);
            label5.TabIndex = 12;
            label5.Text = "По батькові";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 14F);
            label6.ForeColor = Color.Purple;
            label6.Location = new Point(21, 242);
            label6.Name = "label6";
            label6.Size = new Size(101, 25);
            label6.TabIndex = 13;
            label6.Text = "Вік(число)";
            // 
            // listBoxAbonents
            // 
            listBoxAbonents.FormattingEnabled = true;
            listBoxAbonents.Location = new Point(411, 100);
            listBoxAbonents.Name = "listBoxAbonents";
            listBoxAbonents.Size = new Size(243, 199);
            listBoxAbonents.TabIndex = 14;
            listBoxAbonents.SelectedIndexChanged += listBoxAbonents_SelectedIndexChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 20F);
            label7.ForeColor = Color.Blue;
            label7.Location = new Point(388, 39);
            label7.Name = "label7";
            label7.Size = new Size(238, 37);
            label7.TabIndex = 15;
            label7.Text = "Введені абоненти";
            // 
            // CreateAbonente
            // 
            ClientSize = new Size(714, 479);
            Controls.Add(label7);
            Controls.Add(listBoxAbonents);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxName);
            Controls.Add(textBoxLastName);
            Controls.Add(textBoxDadsName);
            Controls.Add(textBoxPhone);
            Controls.Add(textBoxAge);
            Controls.Add(buttonAccept);
            Controls.Add(buttonStop);
            Controls.Add(buttonCreateAbonent);
            Name = "CreateAbonente";
            Text = "Форма користувача";
            ResumeLayout(false);
            PerformLayout();
        }
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private ListBox listBoxAbonents;
        private Label label7;
    }
}